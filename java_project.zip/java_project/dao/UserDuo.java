package java_project.dao;

import java_project.bean.UserDetails;
import java_project.service.DBService;

import java.util.Date;
import java.util.List;

public class UserDuo {
    private static DBService<UserDetails> userDB;

    public UserDuo() {
        userDB = new DBService<>();
        System.out.println("DB Service Created");
    }


    public String createUser(UserDetails userDetails) {
        if (userDetails.validate()) {
            return userDB.addData(userDetails);
        }
        return "";
    }

    public boolean deleteUser(String uid) {
        return userDB.deleteData(uid);
    }

    public String updateUser(String uid, UserDetails data) {
        return userDB.updateData(uid,data);
    }

    public List<UserDetails> getAllUsers() {
        return userDB.getAllData();
    }
}
