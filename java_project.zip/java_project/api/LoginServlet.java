package java_project.api;

import java_project.auth.AuthManager;
import java_project.bean.LoginUserDetail;
import java_project.constants.LoginConstants;
import java_project.service.CommonService;
import org.json.JSONObject;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String payload = CommonService.getPayloadFromRequest(req);
        JSONObject jsonPayload = new JSONObject(payload);
        String login_id = jsonPayload.getString(LoginConstants.LOGIN_ID);
        String password = jsonPayload.getString(LoginConstants.PASSWORD);
        String token = AuthManager.getInstance().generateToken(new LoginUserDetail(login_id,password));
        PrintWriter printWriter = resp.getWriter();
        printWriter.write(token);
    }
}
