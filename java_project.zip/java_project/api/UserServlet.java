package java_project.api;

import java_project.bean.UserDetails;
import java_project.constants.CommonConstants;
import java_project.dao.UserDuo;
import java_project.service.CommonService;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class UserServlet extends HttpServlet {
    private UserDuo userDuo;

    @Override
    public void init() throws ServletException {
        super.init();
        userDuo = new UserDuo();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String cmd = req.getParameter("cmd");
        if (cmd != null && !cmd.trim().isEmpty() && cmd.equals(CommonConstants.GET_USER_DETAILS_CMD)) {
            JSONArray usersArray = new JSONArray();
            userDuo.getAllUsers().forEach(userDetails -> usersArray.put(userDetails.toJson()));
            resp.getWriter().write(usersArray.toString());
        }else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("Invalid Cmd ");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String cmd = req.getParameter("cmd");
        if (cmd != null && !cmd.trim().isEmpty()) {
            String data;
            JSONObject jsonData;
            UserDetails userDetails;
            switch (cmd) {

                case CommonConstants.CREATE_USER_DETAILS_CMD:
                    data = CommonService.getPayloadFromRequest(req);
                    jsonData = new JSONObject(data);
                    userDetails = UserDetails.fromJson(jsonData);
                    if (userDetails.validate()) {
                        String uid = userDuo.createUser(userDetails);
                        if (uid.trim().isEmpty()) {
                            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                            resp.getWriter().write("Error While Creating User");
                        } else {
                            resp.getWriter().write(uid);
                        }
                    } else {
                        resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                        resp.getWriter().write("Enter mandatory Fields");
                    }
                    break;

                case CommonConstants.UPDATE_USER_DETAILS_CMD:
                    String uid = req.getParameter("uid");
                    if (uid != null && !uid.trim().isEmpty()) {
                        data = CommonService.getPayloadFromRequest(req);
                        if (data.trim().isEmpty()){
                            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                            resp.getWriter().write("Body is Empty");
                            return;
                        }
                        jsonData = new JSONObject(data);
                        userDetails = UserDetails.fromJson(jsonData);
                        String updatedUid = userDuo.updateUser(uid, userDetails);
                        if (updatedUid != null && !updatedUid.trim().isEmpty()) {
                            resp.getWriter().write("Successfully Updated");
                        }else {
                            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                            resp.getWriter().write("UUID not found");
                        }
                    } else {
                        resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                        resp.getWriter().write("UUID not found");
                    }
                    break;

                case CommonConstants.DELETE_USER_DETAILS_CMD:
                    uid = req.getParameter("uid");
                    if (uid != null && !uid.trim().isEmpty()) {
                        if (!userDuo.deleteUser(uid)){
                            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                            resp.getWriter().write("Error not deleted");
                        }else {
                            resp.getWriter().write("Successfully deleted");
                        }
                    } else {
                        resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                        resp.getWriter().write("UUID not found");
                    }
                    break;

                default:
                    resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    resp.getWriter().write("Invalid Cmd ");
                    break;
            }
        }
    }

}
