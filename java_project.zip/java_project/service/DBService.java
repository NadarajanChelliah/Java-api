package java_project.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DBService<T> {
    private HashMap<String,T> database = new HashMap<>();

    public String addData(T data){
        String uid = String.valueOf(data.hashCode());
        database.put(uid,data);
        return uid;
    }

    public String  updateData(String uid, T data){
        if (database.get(uid) != null) {
            database.put(uid, data);
            return uid;
        }
        return "";
    }

    public boolean  deleteData(String uid){
        T removedData = database.remove(uid);
        return removedData != null;
    }

    public List<T> getAllData(){
        return new ArrayList<>(database.values());
    }
}
