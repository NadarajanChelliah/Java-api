package java_project.service;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CommonService {
    public static String getPayloadFromRequest(HttpServletRequest request) throws IOException {
        InputStream inputStream = request.getInputStream();
        if (inputStream!=null){
            StringBuffer stringBuffer = new StringBuffer();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String data;
            while ((data = bufferedReader.readLine()) != null){
                stringBuffer.append(data);
            }
            return stringBuffer.toString();
        }
        return "";
    }
}
