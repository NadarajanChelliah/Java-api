package java_project.bean;

import org.json.JSONObject;

public class UserDetails {
    String first_name;
    String last_name;
    String street;
    String address;
    String city;
    String state;
    String email;
    String phone;

    public UserDetails(String first_name, String last_name, String street, String address, String city, String state, String email, String phone) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.street = street;
        this.address = address;
        this.city = city;
        this.state = state;
        this.email = email;
        this.phone = phone;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public boolean validate(){
        return (first_name != null && !first_name.trim().isEmpty() && last_name != null && !last_name.trim().isEmpty());
    }

    public JSONObject toJson(){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("first_name",this.first_name);
        jsonObject.put("last_name",this.last_name);
        jsonObject.put("address",this.address);
        jsonObject.put("street",this.street);
        jsonObject.put("city",this.city);
        jsonObject.put("state",this.state);
        jsonObject.put("email",this.email);
        jsonObject.put("phone",this.phone);
        return jsonObject;
    }

    public static UserDetails fromJson(JSONObject jsonObject) {
        String first_name = jsonObject.has("first_name")?jsonObject.getString("first_name"):null;
        String last_name = jsonObject.has("last_name")?jsonObject.getString("last_name"):null;
        String address = jsonObject.has("address")?jsonObject.getString("address"):null;
        String street = jsonObject.has("street")?jsonObject.getString("street"):null;
        String city = jsonObject.has("city")?jsonObject.getString("city"):null;
        String state = jsonObject.has("state")?jsonObject.getString("state"):null;
        String email = jsonObject.has("email")?jsonObject.getString("email"):null;
        String phone = jsonObject.has("phone")?jsonObject.getString("phone"):null;

        return new UserDetails(first_name,last_name,street,address,city,state,email,phone);
    }
}
