package java_project.constants;

public class CommonConstants {
    public static final String GET_USER_DETAILS_CMD= "get_customer_list";
    public static final String CREATE_USER_DETAILS_CMD= "create";
    public static final String UPDATE_USER_DETAILS_CMD= "update";
    public static final String DELETE_USER_DETAILS_CMD= "delete";
}
