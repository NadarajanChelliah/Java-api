package java_project.constants;

public class LoginConstants {
    public static final String LOGIN_ID = "login_id";
    public static final String PASSWORD = "password";
}
