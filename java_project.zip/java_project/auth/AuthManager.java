package java_project.auth;

import java_project.bean.LoginUserDetail;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class AuthManager {

    private static AuthManager instance;

    private AuthManager(){

    }
    public static AuthManager getInstance() {;
        if (instance == null){
            instance = new AuthManager();
        }
        return instance;
    }
    private static final HashMap<String, LoginUserDetail> tokenList = new HashMap<>();
    public String generateToken(LoginUserDetail loginUserDetail) {
        String input = loginUserDetail.getLogin_id() +"@"+ loginUserDetail.getPassword();

        // Create a SHA-256 message digest instance
        MessageDigest  messageDigest;
        try {
            messageDigest = MessageDigest.getInstance("SHA-256");
        }catch (Exception e){
            return "";
        }

        // Compute the digest for the input string
        byte[] hash = messageDigest.digest(input.getBytes());

        // Convert the byte array to a hexadecimal string
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        tokenList.put(hexString.toString(),loginUserDetail);
        return hexString.toString();
    }

    public LoginUserDetail validateToken(String token){
        return tokenList.getOrDefault(token, null);
    }
}
