package java_project.auth;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class AuthFilter implements Filter {
    List<String> excludedAPIs;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        excludedAPIs = Arrays.stream(filterConfig.getInitParameter("excludedAPI").split(",")).collect(Collectors.toList());
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        String uri = request.getServletPath();
        if (excludedAPIs.contains(uri)){
            filterChain.doFilter(servletRequest,servletResponse);
        }else {
            if (AuthManager.getInstance().validateToken(request.getHeader("Authorization")) != null){
                filterChain.doFilter(servletRequest,servletResponse);
            }else {
                HttpServletResponse response = (HttpServletResponse) servletResponse;
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().write("Unauthorized");
            }
        }
    }

    @Override
    public void destroy() {

    }
}
